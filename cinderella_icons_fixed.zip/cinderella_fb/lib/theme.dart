import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  static const Color primary = Color(0xFF1A0A2E);
  static const Color secondary = Color(0xFFD4AF37);
  static const Color accent = Color(0xFFE8C4D0);
  static const Color background = Color(0xFFFAF8F5);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color textDark = Color(0xFF1A0A2E);
  static const Color textLight = Color(0xFF8A7B9A);
  static const Color error = Color(0xFFE53935);
  static const Color success = Color(0xFF43A047);
  static const Color cardBg = Color(0xFFF5F0F8);
  static const Color divider = Color(0xFFEDE8F3);
}

class AppTheme {
  static ThemeData get theme {
    return ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.primary,
        primary: AppColors.primary,
        secondary: AppColors.secondary,
        surface: AppColors.surface,
        background: AppColors.background,
      ),
      textTheme: GoogleFonts.cormorantTextTheme().copyWith(
        displayLarge: GoogleFonts.cormorant(
          fontSize: 32, fontWeight: FontWeight.w700, color: AppColors.textDark,
          letterSpacing: 1.5,
        ),
        displayMedium: GoogleFonts.cormorant(
          fontSize: 26, fontWeight: FontWeight.w600, color: AppColors.textDark,
        ),
        headlineLarge: GoogleFonts.cormorant(
          fontSize: 22, fontWeight: FontWeight.w700, color: AppColors.textDark,
        ),
        headlineMedium: GoogleFonts.cormorant(
          fontSize: 18, fontWeight: FontWeight.w600, color: AppColors.textDark,
        ),
        bodyLarge: GoogleFonts.raleway(
          fontSize: 14, fontWeight: FontWeight.w500, color: AppColors.textDark,
        ),
        bodyMedium: GoogleFonts.raleway(
          fontSize: 13, fontWeight: FontWeight.w400, color: AppColors.textLight,
        ),
        labelLarge: GoogleFonts.raleway(
          fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.surface,
          letterSpacing: 1.2,
        ),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.background,
        elevation: 0,
        iconTheme: const IconThemeData(color: AppColors.textDark),
        titleTextStyle: GoogleFonts.cormorant(
          fontSize: 20, fontWeight: FontWeight.w700,
          color: AppColors.textDark, letterSpacing: 1.5,
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: AppColors.surface,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 32),
          textStyle: GoogleFonts.raleway(
            fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 1.5,
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.cardBg,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(4),
          borderSide: const BorderSide(color: AppColors.divider),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(4),
          borderSide: const BorderSide(color: AppColors.divider),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(4),
          borderSide: const BorderSide(color: AppColors.primary, width: 1.5),
        ),
        labelStyle: GoogleFonts.raleway(color: AppColors.textLight),
        hintStyle: GoogleFonts.raleway(color: AppColors.textLight, fontSize: 13),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      scaffoldBackgroundColor: AppColors.background,
    );
  }
}
