import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/order.dart';

class OrderService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // ── Place an order ─────────────────────────────────────────────────────────
  Future<String> placeOrder(AppOrder order) async {
    final ref = await _db.collection('orders').add(order.toFirestore());
    return ref.id;
  }

  // ── Get orders for a user ──────────────────────────────────────────────────
  Future<List<AppOrder>> getUserOrders(String userId) async {
    final snap = await _db
        .collection('orders')
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .get();
    return snap.docs.map((d) => AppOrder.fromFirestore(d)).toList();
  }

  // ── Stream orders (real-time) ──────────────────────────────────────────────
  Stream<List<AppOrder>> streamUserOrders(String userId) {
    return _db
        .collection('orders')
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) =>
            snap.docs.map((d) => AppOrder.fromFirestore(d)).toList());
  }
}
