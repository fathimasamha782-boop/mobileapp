import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/product.dart';

class ProductService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // ── Fetch all products ─────────────────────────────────────────────────────
  Future<List<Product>> getProducts() async {
    final snap = await _db.collection('products').get();
    return snap.docs.map((d) => Product.fromFirestore(d)).toList();
  }

  // ── Fetch products by category ─────────────────────────────────────────────
  Future<List<Product>> getByCategory(String category) async {
    final snap = await _db
        .collection('products')
        .where('category', isEqualTo: category)
        .get();
    return snap.docs.map((d) => Product.fromFirestore(d)).toList();
  }

  // ── Fetch featured products ────────────────────────────────────────────────
  Future<List<Product>> getFeatured() async {
    final snap = await _db
        .collection('products')
        .where('isFeatured', isEqualTo: true)
        .get();
    return snap.docs.map((d) => Product.fromFirestore(d)).toList();
  }

  // ── Seed products from local data (run once) ───────────────────────────────
  Future<void> seedProducts(List<Product> products) async {
    final batch = _db.batch();
    for (final p in products) {
      final ref = _db.collection('products').doc(p.id);
      batch.set(ref, p.toFirestore(), SetOptions(merge: true));
    }
    await batch.commit();
  }
}
