import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../theme.dart';
import '../app_state.dart';
import 'login_screen.dart';
import 'order_history_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: const BoxDecoration(
                color: AppColors.primary,
              ),
              child: Column(
                children: [
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppColors.secondary.withOpacity(0.2),
                      border:
                          Border.all(color: AppColors.secondary, width: 2),
                    ),
                    child: Center(
                      child: Text(
                        state.userName.isNotEmpty
                            ? state.userName[0].toUpperCase()
                            : 'C',
                        style: GoogleFonts.cormorant(
                            fontSize: 32,
                            fontWeight: FontWeight.w700,
                            color: AppColors.secondary),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    state.userName.isNotEmpty
                        ? state.userName
                        : 'Guest',
                    style: GoogleFonts.cormorant(
                        fontSize: 22,
                        fontWeight: FontWeight.w700,
                        color: Colors.white),
                  ),
                  if (state.userEmail.isNotEmpty)
                    Text(
                      state.userEmail,
                      style: GoogleFonts.raleway(
                          fontSize: 12,
                          color: AppColors.accent.withOpacity(0.8)),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            // Menu items
            _menuItem(context, Icons.shopping_bag_outlined, 'Order History',
                () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const OrderHistoryScreen()),
                    )),
            _menuItem(context, Icons.favorite_outline, 'Wishlist', () {}),
            _menuItem(
                context, Icons.location_on_outlined, 'Saved Addresses', () {}),
            _menuItem(
                context, Icons.credit_card_outlined, 'Payment Methods', () {}),
            _menuItem(
                context, Icons.notifications_outlined, 'Notifications', () {}),
            _menuItem(
                context, Icons.help_outline, 'Help & Support', () {}),
            _menuItem(
                context, Icons.privacy_tip_outlined, 'Privacy Policy', () {}),
            const Divider(indent: 20, endIndent: 20),
            ListTile(
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
              leading: const Icon(Icons.logout, color: AppColors.error),
              title: Text('Sign Out',
                  style: GoogleFonts.raleway(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: AppColors.error)),
              onTap: () async {
                await state.logout();
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                  (route) => false,
                );
              },
            ),
            const SizedBox(height: 20),
            Text(
              'CINDERELLA v1.0.0',
              style: GoogleFonts.raleway(
                  fontSize: 10,
                  color: AppColors.textLight,
                  letterSpacing: 2),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _menuItem(
      BuildContext context, IconData icon, String label, VoidCallback onTap) {
    return ListTile(
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
      leading: Icon(icon, color: AppColors.textDark, size: 22),
      title: Text(label,
          style: GoogleFonts.raleway(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: AppColors.textDark)),
      trailing: const Icon(Icons.chevron_right,
          color: AppColors.textLight, size: 20),
      onTap: onTap,
    );
  }
}
