import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../theme.dart';
import '../app_state.dart';
import 'login_screen.dart';
import 'main_nav.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late AnimationController _logoController;
  late AnimationController _textController;
  late Animation<double>   _logoFade;
  late Animation<double>   _textFade;
  late Animation<Offset>   _textSlide;

  @override
  void initState() {
    super.initState();
    _logoController = AnimationController(vsync: this,
        duration: const Duration(milliseconds: 1200));
    _textController = AnimationController(vsync: this,
        duration: const Duration(milliseconds: 800));
    _logoFade  = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _logoController, curve: Curves.easeIn));
    _textFade  = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _textController, curve: Curves.easeIn));
    _textSlide = Tween<Offset>(begin: const Offset(0, 0.3), end: Offset.zero)
        .animate(CurvedAnimation(parent: _textController, curve: Curves.easeOut));
    _logoController.forward().then((_) => _textController.forward());

    // After animation, route based on Firebase auth state
    Future.delayed(const Duration(seconds: 3), () {
      if (!mounted) return;
      final isLoggedIn = context.read<AppState>().isLoggedIn;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => isLoggedIn ? const MainNav() : const LoginScreen()),
      );
    });
  }

  @override
  void dispose() {
    _logoController.dispose();
    _textController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primary,
      body: Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          FadeTransition(
            opacity: _logoFade,
            child: Container(
              width: 100, height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.secondary, width: 2)),
              child: const Center(
                child: Icon(Icons.auto_awesome,
                    color: AppColors.secondary, size: 48)),
            ),
          ),
          const SizedBox(height: 24),
          SlideTransition(
            position: _textSlide,
            child: FadeTransition(
              opacity: _textFade,
              child: Column(children: [
                Text('CINDERELLA',
                    style: GoogleFonts.cormorant(
                        fontSize: 38, fontWeight: FontWeight.w700,
                        color: AppColors.secondary, letterSpacing: 6)),
                const SizedBox(height: 8),
                Text('LUXURY FASHION',
                    style: GoogleFonts.raleway(
                        fontSize: 11, fontWeight: FontWeight.w400,
                        color: AppColors.accent.withOpacity(0.8),
                        letterSpacing: 4)),
              ]),
            ),
          ),
          const SizedBox(height: 60),
          FadeTransition(
            opacity: _textFade,
            child: SizedBox(width: 24, height: 24,
              child: CircularProgressIndicator(strokeWidth: 1.5,
                  valueColor: AlwaysStoppedAnimation<Color>(
                      AppColors.secondary.withOpacity(0.6)))),
          ),
        ]),
      ),
    );
  }
}
