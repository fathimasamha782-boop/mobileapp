import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../theme.dart';
import '../app_state.dart';
import '../models/order.dart';

class OrderHistoryScreen extends StatefulWidget {
  const OrderHistoryScreen({super.key});
  @override
  State<OrderHistoryScreen> createState() => _OrderHistoryScreenState();
}

class _OrderHistoryScreenState extends State<OrderHistoryScreen> {
  @override
  Widget build(BuildContext context) {
    final orders = context.watch<AppState>().orders;

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Order History'),
      ),
      body: orders.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.receipt_long_outlined,
                      size: 64, color: AppColors.textLight),
                  const SizedBox(height: 16),
                  Text('No orders yet',
                      style: Theme.of(context).textTheme.headlineMedium),
                  const SizedBox(height: 8),
                  Text('Your orders will appear here',
                      style: Theme.of(context).textTheme.bodyMedium),
                ],
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: orders.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (_, i) => _OrderCard(order: orders[i]),
            ),
    );
  }
}

class _OrderCard extends StatelessWidget {
  final AppOrder order;
  const _OrderCard({required this.order});

  Color _statusColor(String status) {
    switch (status) {
      case 'Delivered': return AppColors.success;
      case 'Shipped':   return const Color(0xFF1565C0);
      default:          return const Color(0xFFE65100);
    }
  }

  @override
  Widget build(BuildContext context) {
    final sc = _statusColor(order.status);
    final firstItem = order.items.isNotEmpty ? order.items.first : null;

    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [BoxShadow(
            color: AppColors.primary.withOpacity(0.05),
            blurRadius: 10, offset: const Offset(0, 2))],
      ),
      child: Column(children: [
        // Header
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('#${order.id.substring(0, 8).toUpperCase()}',
                    style: GoogleFonts.raleway(
                        fontSize: 13, fontWeight: FontWeight.w700,
                        color: AppColors.primary)),
                const SizedBox(height: 2),
                Text(_formatDate(order.createdAt),
                    style: GoogleFonts.raleway(
                        fontSize: 11, color: AppColors.textLight)),
              ],
            )),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: sc.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20)),
              child: Text(order.status,
                  style: GoogleFonts.raleway(
                      fontSize: 11, fontWeight: FontWeight.w700, color: sc)),
            ),
          ]),
        ),
        const Divider(height: 1),
        // Body
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            if (firstItem != null)
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.network(
                  firstItem.imageUrl,
                  width: 56, height: 70, fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    width: 56, height: 70, color: AppColors.cardBg,
                    child: const Icon(Icons.image_not_supported_outlined,
                        color: AppColors.textLight, size: 20)),
                ),
              ),
            const SizedBox(width: 12),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  order.items.map((i) => i.productName).join(', '),
                  style: GoogleFonts.raleway(
                      fontSize: 12, color: AppColors.textLight, height: 1.4),
                  maxLines: 2, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 8),
                Text('Rs. ${order.total.toStringAsFixed(0)}',
                    style: GoogleFonts.cormorant(
                        fontSize: 18, fontWeight: FontWeight.w700,
                        color: AppColors.primary)),
              ],
            )),
          ]),
        ),
        // Actions
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: Row(children: [
            Expanded(child: OutlinedButton(
              onPressed: () => _showDetails(context),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppColors.divider),
                padding: const EdgeInsets.symmetric(vertical: 10),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(4))),
              child: Text('View Details',
                  style: GoogleFonts.raleway(
                      fontSize: 12, fontWeight: FontWeight.w600,
                      color: AppColors.textDark)),
            )),
          ]),
        ),
      ]),
    );
  }

  String _formatDate(DateTime dt) {
    const months = ['Jan','Feb','Mar','Apr','May','Jun',
                    'Jul','Aug','Sep','Oct','Nov','Dec'];
    return '${dt.day} ${months[dt.month - 1]} ${dt.year}';
  }

  void _showDetails(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Order Details',
                style: GoogleFonts.cormorant(
                    fontSize: 20, fontWeight: FontWeight.w700,
                    color: AppColors.textDark)),
            const SizedBox(height: 12),
            Text('Deliver to: ${order.name}',
                style: GoogleFonts.raleway(fontSize: 13)),
            Text('${order.address}, ${order.city} ${order.postalCode}',
                style: GoogleFonts.raleway(
                    fontSize: 12, color: AppColors.textLight)),
            Text('Phone: ${order.phone}',
                style: GoogleFonts.raleway(
                    fontSize: 12, color: AppColors.textLight)),
            const Divider(),
            ...order.items.map((item) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(children: [
                Expanded(child: Text(
                  '${item.productName} × ${item.quantity}  (${item.size}, ${item.color})',
                  style: GoogleFonts.raleway(fontSize: 12))),
                Text('Rs. ${item.total.toStringAsFixed(0)}',
                    style: GoogleFonts.raleway(
                        fontSize: 12, fontWeight: FontWeight.w600)),
              ]),
            )),
            const Divider(),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Total', style: GoogleFonts.cormorant(
                    fontSize: 16, fontWeight: FontWeight.w700)),
                Text('Rs. ${order.total.toStringAsFixed(0)}',
                    style: GoogleFonts.cormorant(
                        fontSize: 18, fontWeight: FontWeight.w700,
                        color: AppColors.primary)),
              ]),
          ]),
      ),
    );
  }
}
