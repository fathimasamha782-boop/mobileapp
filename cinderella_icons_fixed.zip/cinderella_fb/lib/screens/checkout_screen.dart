import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../theme.dart';
import '../app_state.dart';
import 'main_nav.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});
  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final _nameController    = TextEditingController();
  final _phoneController   = TextEditingController();
  final _addressController = TextEditingController();
  final _cityController    = TextEditingController();
  final _postalController  = TextEditingController();
  int  _paymentMethod  = 0;
  bool _isPlacingOrder = false;

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _addressController.dispose();
    _cityController.dispose();
    _postalController.dispose();
    super.dispose();
  }

  void _placeOrder() async {
    if (_nameController.text.trim().isEmpty ||
        _addressController.text.trim().isEmpty ||
        _cityController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please fill in all delivery details')));
      return;
    }
    setState(() => _isPlacingOrder = true);

    final paymentLabels = [
      'Cash on Delivery', 'Credit / Debit Card', 'Online Banking'
    ];

    // ── Save order to Firestore ────────────────────────────────────────────
    final orderId = await context.read<AppState>().placeOrder(
      name:          _nameController.text.trim(),
      phone:         _phoneController.text.trim(),
      address:       _addressController.text.trim(),
      city:          _cityController.text.trim(),
      postalCode:    _postalController.text.trim(),
      paymentMethod: paymentLabels[_paymentMethod],
    );

    if (!mounted) return;
    setState(() => _isPlacingOrder = false);

    if (orderId != null) {
      _showOrderSuccess(orderId);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to place order. Try again.')));
    }
  }

  void _showOrderSuccess(String orderId) {
    final navigator = Navigator.of(context);
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dCtx) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 72, height: 72,
              decoration: BoxDecoration(
                color: AppColors.success.withOpacity(0.1),
                shape: BoxShape.circle),
              child: const Icon(Icons.check_circle,
                  color: AppColors.success, size: 40),
            ),
            const SizedBox(height: 16),
            Text('Order Placed!',
                style: GoogleFonts.cormorant(
                    fontSize: 24, fontWeight: FontWeight.w700,
                    color: AppColors.textDark)),
            const SizedBox(height: 8),
            Text(
              'Order #${orderId.substring(0, 8).toUpperCase()}\nhas been confirmed.',
              textAlign: TextAlign.center,
              style: GoogleFonts.raleway(
                  fontSize: 13, color: AppColors.textLight, height: 1.5),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.of(dCtx).pop();
                  navigator.pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const MainNav()),
                    (route) => false,
                  );
                },
                child: const Text('CONTINUE SHOPPING'),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<AppState>().cart;
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Checkout'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Delivery Details',
              style: Theme.of(context).textTheme.headlineLarge),
          const SizedBox(height: 16),
          _field(_nameController,    'Full Name',      TextInputType.name),
          const SizedBox(height: 12),
          _field(_phoneController,   'Phone Number',   TextInputType.phone),
          const SizedBox(height: 12),
          _field(_addressController, 'Street Address',
              TextInputType.streetAddress, maxLines: 2),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: _field(_cityController, 'City', TextInputType.text)),
            const SizedBox(width: 12),
            Expanded(child: _field(_postalController, 'Postal Code',
                TextInputType.number)),
          ]),
          const SizedBox(height: 24),
          Text('Payment Method',
              style: Theme.of(context).textTheme.headlineLarge),
          const SizedBox(height: 12),
          ...['Cash on Delivery', 'Credit / Debit Card', 'Online Banking']
              .asMap()
              .entries
              .map((e) => _payTile(e.key, e.value)),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.cardBg,
              borderRadius: BorderRadius.circular(8)),
            child: Column(children: [
              Text('Order Summary',
                  style: GoogleFonts.cormorant(
                      fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 12),
              ...cart.items.map((item) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(children: [
                  Expanded(child: Text(
                    '${item.product.name} × ${item.quantity}',
                    style: GoogleFonts.raleway(
                        fontSize: 12, color: AppColors.textLight))),
                  Text('Rs. ${item.totalPrice.toStringAsFixed(0)}',
                      style: GoogleFonts.raleway(
                          fontSize: 12, fontWeight: FontWeight.w600,
                          color: AppColors.textDark)),
                ]),
              )),
              const Divider(),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Total', style: GoogleFonts.cormorant(
                      fontSize: 18, fontWeight: FontWeight.w700)),
                  Text('Rs. ${cart.total.toStringAsFixed(0)}',
                      style: GoogleFonts.cormorant(
                          fontSize: 20, fontWeight: FontWeight.w700,
                          color: AppColors.primary)),
                ]),
            ]),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _isPlacingOrder ? null : _placeOrder,
              child: _isPlacingOrder
                  ? const SizedBox(width: 20, height: 20,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white))
                  : const Text('PLACE ORDER'),
            ),
          ),
          const SizedBox(height: 32),
        ]),
      ),
    );
  }

  Widget _field(TextEditingController ctrl, String label,
      TextInputType keyboard, {int maxLines = 1}) =>
    TextField(
      controller: ctrl, keyboardType: keyboard, maxLines: maxLines,
      decoration: InputDecoration(labelText: label));

  Widget _payTile(int index, String label) {
    final selected = _paymentMethod == index;
    final icons = [Icons.money_outlined, Icons.credit_card_outlined,
        Icons.account_balance_outlined];
    return GestureDetector(
      onTap: () => setState(() => _paymentMethod = index),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        decoration: BoxDecoration(
          color: selected
              ? AppColors.primary.withOpacity(0.05)
              : AppColors.cardBg,
          border: Border.all(
            color: selected ? AppColors.primary : AppColors.divider,
            width: selected ? 1.5 : 1),
          borderRadius: BorderRadius.circular(8)),
        child: ListTile(
          leading: Icon(icons[index],
              color: selected ? AppColors.primary : AppColors.textLight,
              size: 20),
          title: Text(label,
              style: GoogleFonts.raleway(
                  fontSize: 13, fontWeight: FontWeight.w600,
                  color: selected ? AppColors.primary : AppColors.textDark)),
          trailing: selected
              ? const Icon(Icons.check_circle,
                  color: AppColors.primary, size: 18)
              : null,
        ),
      ),
    );
  }
}
