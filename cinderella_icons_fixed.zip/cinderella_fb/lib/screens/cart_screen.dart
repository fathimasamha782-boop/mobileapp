import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../theme.dart';
import '../app_state.dart';
import 'checkout_screen.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final cart = state.cart;

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Bag'),
        actions: [
          if (cart.items.isNotEmpty)
            TextButton(
              onPressed: () => state.clearCart(),
              child: Text('Clear All',
                  style: GoogleFonts.raleway(
                      fontSize: 12, color: AppColors.error)),
            ),
        ],
      ),
      body: cart.items.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.shopping_bag_outlined,
                      size: 64, color: AppColors.textLight),
                  const SizedBox(height: 16),
                  Text('Your bag is empty',
                      style: Theme.of(context).textTheme.headlineMedium),
                  const SizedBox(height: 8),
                  Text('Add items to get started',
                      style: Theme.of(context).textTheme.bodyMedium),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('CONTINUE SHOPPING'),
                  ),
                ],
              ),
            )
          : Column(
              children: [
                Expanded(
                  child: ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: cart.items.length,
                    separatorBuilder: (_, __) => const Divider(),
                    itemBuilder: (_, i) {
                      final item = cart.items[i];
                      return Row(
                        children: [
                          // Image
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.network(
                              item.product.imageUrl,
                              width: 80,
                              height: 100,
                              fit: BoxFit.cover,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(item.product.brand,
                                    style: GoogleFonts.raleway(
                                        fontSize: 10,
                                        color: AppColors.secondary,
                                        fontWeight: FontWeight.w600,
                                        letterSpacing: 1)),
                                Text(item.product.name,
                                    style: GoogleFonts.cormorant(
                                        fontSize: 15,
                                        fontWeight: FontWeight.w600)),
                                const SizedBox(height: 4),
                                Text(
                                  '${item.selectedSize} • ${item.selectedColor}',
                                  style: GoogleFonts.raleway(
                                      fontSize: 11,
                                      color: AppColors.textLight),
                                ),
                                const SizedBox(height: 8),
                                Row(
                                  children: [
                                    Text(
                                      'Rs. ${item.totalPrice.toStringAsFixed(0)}',
                                      style: GoogleFonts.raleway(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w700,
                                          color: AppColors.primary),
                                    ),
                                    const Spacer(),
                                    // Qty controls
                                    Container(
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                            color: AppColors.divider),
                                        borderRadius:
                                            BorderRadius.circular(4),
                                      ),
                                      child: Row(
                                        children: [
                                          GestureDetector(
                                            onTap: () =>
                                                state.updateCartQuantity(
                                                    item.product.id,
                                                    item.quantity - 1),
                                            child: const Padding(
                                              padding: EdgeInsets.all(6),
                                              child: Icon(Icons.remove,
                                                  size: 14),
                                            ),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 10),
                                            child: Text('${item.quantity}',
                                                style: GoogleFonts.raleway(
                                                    fontWeight:
                                                        FontWeight.w700,
                                                    fontSize: 13)),
                                          ),
                                          GestureDetector(
                                            onTap: () =>
                                                state.updateCartQuantity(
                                                    item.product.id,
                                                    item.quantity + 1),
                                            child: const Padding(
                                              padding: EdgeInsets.all(6),
                                              child:
                                                  Icon(Icons.add, size: 14),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    GestureDetector(
                                      onTap: () => state
                                          .removeFromCart(item.product.id),
                                      child: const Icon(Icons.delete_outline,
                                          size: 18,
                                          color: AppColors.textLight),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
                // Summary
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.primary.withOpacity(0.08),
                        blurRadius: 20,
                        offset: const Offset(0, -4),
                      )
                    ],
                  ),
                  child: Column(
                    children: [
                      _summaryRow(context, 'Subtotal',
                          'Rs. ${cart.subtotal.toStringAsFixed(0)}'),
                      const SizedBox(height: 8),
                      _summaryRow(
                          context,
                          'Shipping',
                          cart.shipping == 0
                              ? 'FREE'
                              : 'Rs. ${cart.shipping.toStringAsFixed(0)}'),
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 12),
                        child: Divider(),
                      ),
                      _summaryRow(context, 'Total',
                          'Rs. ${cart.total.toStringAsFixed(0)}',
                          isBold: true),
                      const SizedBox(height: 16),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => const CheckoutScreen()),
                          ),
                          child: const Text('PROCEED TO CHECKOUT'),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }

  Widget _summaryRow(BuildContext context, String label, String value,
      {bool isBold = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: isBold
                ? GoogleFonts.cormorant(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textDark)
                : GoogleFonts.raleway(
                    fontSize: 13, color: AppColors.textLight)),
        Text(value,
            style: isBold
                ? GoogleFonts.cormorant(
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    color: AppColors.primary)
                : GoogleFonts.raleway(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: value == 'FREE'
                        ? AppColors.success
                        : AppColors.textDark)),
      ],
    );
  }
}
