// File generated based on your Firebase project configuration
// Project: cinderella-fashion
// Project ID: cinderella-fashion-bf52e

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  // ── Android (from your google-services.json) ───────────────────────────────
  static const FirebaseOptions android = FirebaseOptions(
    apiKey:            'AIzaSyClxWOO1RTid-kFyq6NgQWgZH7A4qMYXjA',
    appId:             '1:266827873352:android:035d0e6de4a07aeeb6ac7d',
    messagingSenderId: '266827873352',
    projectId:         'cinderella-fashion-bf52e',
    storageBucket:     'cinderella-fashion-bf52e.firebasestorage.app',
  );

  // ── iOS (fill in if you add an iOS app to Firebase later) ─────────────────
  static const FirebaseOptions ios = FirebaseOptions(
    apiKey:            'AIzaSyClxWOO1RTid-kFyq6NgQWgZH7A4qMYXjA',
    appId:             '1:266827873352:ios:REPLACE_WITH_IOS_APP_ID',
    messagingSenderId: '266827873352',
    projectId:         'cinderella-fashion-bf52e',
    storageBucket:     'cinderella-fashion-bf52e.firebasestorage.app',
    iosBundleId:       'com.cinderella.app',
  );

  // ── Web (fill in if you add a Web app to Firebase later) ──────────────────
  static const FirebaseOptions web = FirebaseOptions(
    apiKey:            'AIzaSyClxWOO1RTid-kFyq6NgQWgZH7A4qMYXjA',
    appId:             '1:266827873352:web:REPLACE_WITH_WEB_APP_ID',
    messagingSenderId: '266827873352',
    projectId:         'cinderella-fashion-bf52e',
    storageBucket:     'cinderella-fashion-bf52e.firebasestorage.app',
    authDomain:        'cinderella-fashion-bf52e.firebaseapp.com',
  );
}
