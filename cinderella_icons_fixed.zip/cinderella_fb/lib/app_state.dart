import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'models/cart.dart';
import 'models/product.dart';
import 'models/order.dart';
import 'services/auth_service.dart';
import 'services/product_service.dart';
import 'services/order_service.dart';
import 'data/products.dart';

class AppState extends ChangeNotifier {
  final AuthService     _authService    = AuthService();
  final ProductService  _productService = ProductService();
  final OrderService    _orderService   = OrderService();

  final CartModel  _cart     = CartModel();
  final List<String> _wishlist = [];

  List<Product> _products = [];
  List<AppOrder> _orders  = [];
  bool _productsLoaded    = false;
  bool _loadingProducts   = false;
  String _productError    = '';

  User?   _firebaseUser;
  bool    _isLoggedIn = false;
  String  _userName   = '';
  String  _userEmail  = '';
  String? _authError;

  // ── Getters ────────────────────────────────────────────────────────────────
  CartModel      get cart           => _cart;
  List<String>   get wishlist       => List.unmodifiable(_wishlist);
  bool           get isLoggedIn     => _isLoggedIn;
  String         get userName       => _userName;
  String         get userEmail      => _userEmail;
  String?        get authError      => _authError;
  String?        get userId         => _firebaseUser?.uid;
  List<Product>  get products       => _products;
  List<AppOrder> get orders         => _orders;
  bool           get loadingProducts => _loadingProducts;
  String         get productError   => _productError;

  // ── Init: listen to Firebase auth state ───────────────────────────────────
  void init() {
    _authService.authStateChanges.listen((User? user) async {
      _firebaseUser = user;
      if (user != null) {
        _isLoggedIn = true;
        _userEmail  = user.email ?? '';
        _userName   = user.displayName ?? user.email!.split('@')[0];
        await _loadProducts();
        await _loadOrders();
      } else {
        _isLoggedIn = false;
        _userName   = '';
        _userEmail  = '';
        _orders     = [];
      }
      notifyListeners();
    });
  }

  // ── Load products from Firestore (with local fallback) ────────────────────
  Future<void> _loadProducts() async {
    if (_productsLoaded) return;
    _loadingProducts = true;
    _productError    = '';
    notifyListeners();
    try {
      final fetched = await _productService.getProducts();
      if (fetched.isEmpty) {
        // First run: seed Firestore from local data
        await _productService.seedProducts(sampleProducts);
        _products = sampleProducts;
      } else {
        _products = fetched;
      }
      _productsLoaded = true;
    } catch (e) {
      _productError = 'Failed to load products. Using local data.';
      _products     = sampleProducts;
      _productsLoaded = true;
    }
    _loadingProducts = false;
    notifyListeners();
  }

  // ── Load orders from Firestore ─────────────────────────────────────────────
  Future<void> _loadOrders() async {
    if (_firebaseUser == null) return;
    try {
      _orders = await _orderService.getUserOrders(_firebaseUser!.uid);
      notifyListeners();
    } catch (_) {}
  }

  // ── Auth: Login ────────────────────────────────────────────────────────────
  Future<bool> login(String email, String password) async {
    _authError = null;
    notifyListeners();
    try {
      await _authService.login(email: email, password: password);
      return true;
    } on FirebaseAuthException catch (e) {
      _authError = _friendlyAuthError(e.code);
      notifyListeners();
      return false;
    }
  }

  // ── Auth: Register ─────────────────────────────────────────────────────────
  Future<bool> register(String name, String email, String password) async {
    _authError = null;
    notifyListeners();
    try {
      await _authService.register(
          name: name, email: email, password: password);
      return true;
    } on FirebaseAuthException catch (e) {
      _authError = _friendlyAuthError(e.code);
      notifyListeners();
      return false;
    }
  }

  // ── Auth: Logout ───────────────────────────────────────────────────────────
  Future<void> logout() async {
    await _authService.logout();
    _cart.clear();
    _wishlist.clear();
    notifyListeners();
  }

  // ── Auth: Reset password ───────────────────────────────────────────────────
  Future<void> resetPassword(String email) =>
      _authService.resetPassword(email);

  // ── Cart ───────────────────────────────────────────────────────────────────
  void addToCart(Product product, String size, String color) {
    _cart.addItem(product, size, color);
    notifyListeners();
  }

  void removeFromCart(String productId) {
    _cart.removeItem(productId);
    notifyListeners();
  }

  void updateCartQuantity(String productId, int qty) {
    _cart.updateQuantity(productId, qty);
    notifyListeners();
  }

  Future<void> clearCart() async {
    _cart.clear();
    notifyListeners();
  }

  // ── Place order (saves to Firestore) ──────────────────────────────────────
  Future<String?> placeOrder({
    required String name,
    required String phone,
    required String address,
    required String city,
    required String postalCode,
    required String paymentMethod,
  }) async {
    if (_firebaseUser == null) return null;
    final order = AppOrder(
      id:            '',
      userId:        _firebaseUser!.uid,
      items:         _cart.items
          .map((i) => OrderItem(
                productId:   i.product.id,
                productName: i.product.name,
                imageUrl:    i.product.imageUrl,
                price:       i.product.price,
                quantity:    i.quantity,
                size:        i.selectedSize,
                color:       i.selectedColor,
              ))
          .toList(),
      subtotal:      _cart.subtotal,
      shipping:      _cart.shipping,
      total:         _cart.total,
      name:          name,
      phone:         phone,
      address:       address,
      city:          city,
      postalCode:    postalCode,
      paymentMethod: paymentMethod,
      createdAt:     DateTime.now(),
    );
    try {
      final id = await _orderService.placeOrder(order);
      await clearCart();
      await _loadOrders();
      return id;
    } catch (e) {
      return null;
    }
  }

  // ── Wishlist ───────────────────────────────────────────────────────────────
  void toggleWishlist(String productId) {
    _wishlist.contains(productId)
        ? _wishlist.remove(productId)
        : _wishlist.add(productId);
    notifyListeners();
  }

  bool isWishlisted(String productId) => _wishlist.contains(productId);

  // ── Helper: human-readable Firebase error ─────────────────────────────────
  String _friendlyAuthError(String code) {
    switch (code) {
      case 'user-not-found':
        return 'No account found with this email.';
      case 'wrong-password':
        return 'Incorrect password. Please try again.';
      case 'email-already-in-use':
        return 'An account with this email already exists.';
      case 'weak-password':
        return 'Password must be at least 6 characters.';
      case 'invalid-email':
        return 'Please enter a valid email address.';
      case 'too-many-requests':
        return 'Too many attempts. Please try again later.';
      case 'network-request-failed':
        return 'Network error. Check your internet connection.';
      default:
        return 'Authentication error. Please try again.';
    }
  }
}
