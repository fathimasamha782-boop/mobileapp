import 'package:cloud_firestore/cloud_firestore.dart';

class Product {
  final String id;
  final String name;
  final String brand;
  final String category;
  final double price;
  final double? originalPrice;
  final String imageUrl;
  final List<String> images;
  final String description;
  final List<String> sizes;
  final List<String> colors;
  final double rating;
  final int reviewCount;
  final bool isFeatured;
  final bool isNew;

  const Product({
    required this.id,
    required this.name,
    required this.brand,
    required this.category,
    required this.price,
    this.originalPrice,
    required this.imageUrl,
    this.images = const [],
    required this.description,
    this.sizes = const [],
    this.colors = const [],
    this.rating = 4.5,
    this.reviewCount = 0,
    this.isFeatured = false,
    this.isNew = false,
  });

  bool get isOnSale => originalPrice != null && originalPrice! > price;
  int get discountPercent {
    if (!isOnSale) return 0;
    return (((originalPrice! - price) / originalPrice!) * 100).round();
  }

  // ── Firestore deserialization ──────────────────────────────────────────────
  factory Product.fromFirestore(DocumentSnapshot doc) {
    final d = doc.data() as Map<String, dynamic>;
    return Product(
      id:           doc.id,
      name:         d['name']        ?? '',
      brand:        d['brand']       ?? '',
      category:     d['category']    ?? '',
      price:        (d['price']      ?? 0).toDouble(),
      originalPrice: d['originalPrice'] != null
          ? (d['originalPrice'] as num).toDouble()
          : null,
      imageUrl:     d['imageUrl']    ?? '',
      images:       List<String>.from(d['images'] ?? []),
      description:  d['description'] ?? '',
      sizes:        List<String>.from(d['sizes']  ?? []),
      colors:       List<String>.from(d['colors'] ?? []),
      rating:       (d['rating']     ?? 4.5).toDouble(),
      reviewCount:  (d['reviewCount'] ?? 0).toInt(),
      isFeatured:   d['isFeatured']  ?? false,
      isNew:        d['isNew']       ?? false,
    );
  }

  // ── Firestore serialization ────────────────────────────────────────────────
  Map<String, dynamic> toFirestore() => {
    'name':         name,
    'brand':        brand,
    'category':     category,
    'price':        price,
    if (originalPrice != null) 'originalPrice': originalPrice,
    'imageUrl':     imageUrl,
    'images':       images,
    'description':  description,
    'sizes':        sizes,
    'colors':       colors,
    'rating':       rating,
    'reviewCount':  reviewCount,
    'isFeatured':   isFeatured,
    'isNew':        isNew,
  };
}
