import 'package:cloud_firestore/cloud_firestore.dart';

class OrderItem {
  final String productId;
  final String productName;
  final String imageUrl;
  final double price;
  final int quantity;
  final String size;
  final String color;

  const OrderItem({
    required this.productId,
    required this.productName,
    required this.imageUrl,
    required this.price,
    required this.quantity,
    required this.size,
    required this.color,
  });

  double get total => price * quantity;

  Map<String, dynamic> toMap() => {
    'productId':   productId,
    'productName': productName,
    'imageUrl':    imageUrl,
    'price':       price,
    'quantity':    quantity,
    'size':        size,
    'color':       color,
  };

  factory OrderItem.fromMap(Map<String, dynamic> m) => OrderItem(
    productId:   m['productId']   ?? '',
    productName: m['productName'] ?? '',
    imageUrl:    m['imageUrl']    ?? '',
    price:       (m['price']      ?? 0).toDouble(),
    quantity:    (m['quantity']   ?? 1).toInt(),
    size:        m['size']        ?? '',
    color:       m['color']       ?? '',
  );
}

class AppOrder {
  final String id;
  final String userId;
  final List<OrderItem> items;
  final double subtotal;
  final double shipping;
  final double total;
  final String name;
  final String phone;
  final String address;
  final String city;
  final String postalCode;
  final String paymentMethod;
  final String status;          // 'Processing' | 'Shipped' | 'Delivered'
  final DateTime createdAt;

  const AppOrder({
    required this.id,
    required this.userId,
    required this.items,
    required this.subtotal,
    required this.shipping,
    required this.total,
    required this.name,
    required this.phone,
    required this.address,
    required this.city,
    required this.postalCode,
    required this.paymentMethod,
    this.status = 'Processing',
    required this.createdAt,
  });

  factory AppOrder.fromFirestore(DocumentSnapshot doc) {
    final d = doc.data() as Map<String, dynamic>;
    return AppOrder(
      id:            doc.id,
      userId:        d['userId']        ?? '',
      items:         (d['items'] as List? ?? [])
          .map((i) => OrderItem.fromMap(i as Map<String, dynamic>))
          .toList(),
      subtotal:      (d['subtotal']     ?? 0).toDouble(),
      shipping:      (d['shipping']     ?? 0).toDouble(),
      total:         (d['total']        ?? 0).toDouble(),
      name:          d['name']          ?? '',
      phone:         d['phone']         ?? '',
      address:       d['address']       ?? '',
      city:          d['city']          ?? '',
      postalCode:    d['postalCode']    ?? '',
      paymentMethod: d['paymentMethod'] ?? '',
      status:        d['status']        ?? 'Processing',
      createdAt:     (d['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toFirestore() => {
    'userId':        userId,
    'items':         items.map((i) => i.toMap()).toList(),
    'subtotal':      subtotal,
    'shipping':      shipping,
    'total':         total,
    'name':          name,
    'phone':         phone,
    'address':       address,
    'city':          city,
    'postalCode':    postalCode,
    'paymentMethod': paymentMethod,
    'status':        status,
    'createdAt':     FieldValue.serverTimestamp(),
  };
}
