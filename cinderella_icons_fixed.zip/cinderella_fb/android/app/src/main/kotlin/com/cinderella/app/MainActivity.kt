package com.cinderella.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
